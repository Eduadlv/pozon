
# Barras contra el destino
Este es un reportaje interactivo sobre jóvenes de El Pozón, Cartagena.

## Cómo visualizar
1. Abrir `index.html` en cualquier navegador.
2. Para publicar en GitHub Pages:
   - Crear un repositorio nuevo.
   - Subir estos archivos.
   - Ir a Settings > Pages y activar GitHub Pages.

## Créditos
Proyecto de ciencia ciudadana Mi Voz.
